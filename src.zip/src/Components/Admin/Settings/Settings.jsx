import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Switch,
  Alert,
  Modal,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { supabase } from '../../../lib/supabase';
import Svg2, { Path, Circle, Line, Polyline, Rect } from 'react-native-svg';
import BackArrow from '../../../assets/back-arrow.svg';
import { APP_NAME, APP_VERSION, LOW_STOCK_ALERT_THRESHOLD } from '../../../constants';

const BLUE = '#2D2F8E';

// ─── Icons ────────────────────────────────────────────────────────────────────
const UserIcon = ({ size = 20, color = BLUE }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Circle cx="12" cy="7" r="4" stroke={color} strokeWidth="2" />
  </Svg2>
);

const BellIcon = ({ size = 20, color = BLUE }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M13.73 21a2 2 0 0 1-3.46 0" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg2>
);

const LockIcon = ({ size = 20, color = BLUE }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke={color} strokeWidth="2" />
    <Path d="M7 11V7a5 5 0 0 1 10 0v4" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg2>
);

const PrinterIcon = ({ size = 20, color = BLUE }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Polyline points="6 9 6 2 18 2 18 9" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Rect x="6" y="14" width="12" height="8" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg2>
);

const GSTIcon = ({ size = 20, color = BLUE }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Path d="M12 2L2 7l10 5 10-5-10-5z" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M2 17l10 5 10-5" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M2 12l10 5 10-5" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg2>
);

const StoreIcon = ({ size = 20, color = BLUE }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <Polyline points="9 22 9 12 15 12 15 22" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg2>
);

const ChevronRight = ({ size = 16, color = '#94A3B8' }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Polyline points="9 18 15 12 9 6" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </Svg2>
);

const InfoIcon = ({ size = 20, color = BLUE }) => (
  <Svg2 width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="12" r="10" stroke={color} strokeWidth="2" />
    <Line x1="12" y1="8" x2="12" y2="12" stroke={color} strokeWidth="2" strokeLinecap="round" />
    <Line x1="12" y1="16" x2="12.01" y2="16" stroke={color} strokeWidth="2" strokeLinecap="round" />
  </Svg2>
);

// ─── Setting Row Components ───────────────────────────────────────────────────
const SettingToggle = ({ icon, label, subtitle, value, onToggle }) => (
  <View style={s.row}>
    <View style={s.rowIcon}>{icon}</View>
    <View style={s.rowText}>
      <Text style={s.rowLabel}>{label}</Text>
      {subtitle ? <Text style={s.rowSub}>{subtitle}</Text> : null}
    </View>
    <Switch
      value={value}
      onValueChange={onToggle}
      trackColor={{ false: '#E2E8F0', true: `${BLUE}55` }}
      thumbColor={value ? BLUE : '#94A3B8'}
    />
  </View>
);

const SettingLink = ({ icon, label, subtitle, onPress, danger }) => (
  <TouchableOpacity style={s.row} onPress={onPress} activeOpacity={0.7}>
    <View style={[s.rowIcon, danger && s.rowIconDanger]}>{icon}</View>
    <View style={s.rowText}>
      <Text style={[s.rowLabel, danger && s.rowLabelDanger]}>{label}</Text>
      {subtitle ? <Text style={s.rowSub}>{subtitle}</Text> : null}
    </View>
    <ChevronRight />
  </TouchableOpacity>
);

const SectionHeader = ({ title }) => (
  <Text style={s.sectionHeader}>{title}</Text>
);

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function SettingsScreen() {
  const navigation = useNavigation();
  const { signOut, profile } = useAuth();

  // Build display name and initials from profile
  const displayName = profile?.full_name || profile?.username || 'Admin';
  const initials    = displayName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  const roleLabel   = profile?.role
    ? profile.role.charAt(0).toUpperCase() + profile.role.slice(1)
    : 'Administrator';
  const roleBadge   = (profile?.role || 'admin').toUpperCase();

  const [notifications, setNotifications] = useState(true);
  const [lowStockAlert, setLowStockAlert]   = useState(true);
  const [soundEnabled, setSoundEnabled]     = useState(false);
  const [autoPrint, setAutoPrint]           = useState(false);

  const [passwordModalVisible, setPasswordModalVisible] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);

  const handleChangePassword = async () => {
    if (!newPassword || newPassword.length < 6) {
      Alert.alert('Invalid Password', 'Password must be at least 6 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      Alert.alert('Mismatch', 'Passwords do not match.');
      return;
    }

    setChangingPassword(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      
      Alert.alert('Success', 'Your password has been successfully updated.');
      setPasswordModalVisible(false);
      setNewPassword('');
      setConfirmPassword('');
    } catch (e) {
      Alert.alert('Error', e.message || 'Failed to update password.');
    } finally {
      setChangingPassword(false);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: () => signOut(),
        },
      ]
    );
  };

  return (
    <SafeAreaView style={s.safe}>
      {/* HEADER */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.backBtn}>
          <BackArrow width={20} height={20} fill={BLUE} stroke={BLUE} />
        </TouchableOpacity>
        <View style={s.headerCenter}>
          <Text style={s.headerTitle}>Settings</Text>
          <Text style={s.headerSub}>Vishnu Mobile Shop</Text>
        </View>
        <View style={{ width: 36 }} />
      </View>

      <Modal visible={passwordModalVisible} transparent animationType="slide" onRequestClose={() => setPasswordModalVisible(false)}>
        <View style={s.overlay}>
          <View style={s.sheet}>
            <View style={s.handle} />
            <Text style={s.sheetTitle}>Change Password</Text>
            <Text style={s.sheetSub}>Enter your new password below.</Text>

            <Text style={s.lbl}>NEW PASSWORD</Text>
            <TextInput 
              style={s.inp} 
              placeholder="Min 6 characters" 
              placeholderTextColor="#bbb" 
              secureTextEntry
              value={newPassword}
              onChangeText={setNewPassword}
              editable={!changingPassword}
            />

            <Text style={s.lbl}>CONFIRM PASSWORD</Text>
            <TextInput 
              style={s.inp} 
              placeholder="Confirm new password" 
              placeholderTextColor="#bbb" 
              secureTextEntry
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              editable={!changingPassword}
            />

            <View style={s.btnRow}>
              <TouchableOpacity style={s.cancelBtn} onPress={() => setPasswordModalVisible(false)} disabled={changingPassword}>
                <Text style={s.cancelTxt}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.saveBtn, changingPassword && { opacity: 0.7 }]} onPress={handleChangePassword} disabled={changingPassword}>
                {changingPassword ? <ActivityIndicator color="#fff" size="small" /> : <Text style={s.saveTxt}>Update Password</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>

        {/* Profile Card */}
        <View style={s.profileCard}>
          <View style={s.profileAvatar}>
            <Text style={s.profileAvatarText}>{initials}</Text>
          </View>
          <View style={s.profileText}>
            <Text style={s.profileName}>{displayName}</Text>
            <Text style={s.profileRole}>{roleLabel}</Text>
          </View>
          <View style={s.profileBadge}>
            <Text style={s.profileBadgeText}>{roleBadge}</Text>
          </View>
        </View>

        {/* Store Info */}
        <SectionHeader title="STORE INFORMATION" />
        <View style={s.card}>
          <SettingLink
            icon={<StoreIcon />}
            label="Shop Name"
            subtitle={APP_NAME}
            onPress={() => Alert.alert('Shop Name', 'Edit shop name — coming soon!')}
          />
          <View style={s.sep} />
          <SettingLink
            icon={<GSTIcon />}
            label="GST Number"
            subtitle="GST rate: 18% · Edit GSTIN"
            onPress={() => Alert.alert('GST Settings', 'Edit GST number — coming soon!')}
          />
          <View style={s.sep} />
          <SettingLink
            icon={<UserIcon />}
            label="Account & Profile"
            subtitle="Manage owner details"
            onPress={() => Alert.alert('Profile', 'Edit profile — coming soon!')}
          />
        </View>

        {/* Notifications */}
        <SectionHeader title="NOTIFICATIONS" />
        <View style={s.card}>
          <SettingToggle
            icon={<BellIcon />}
            label="Push Notifications"
            subtitle="Sales, alerts & updates"
            value={notifications}
            onToggle={setNotifications}
          />
          <View style={s.sep} />
          <SettingToggle
            icon={<BellIcon color="#f59e0b" />}
            label="Low Stock Alerts"
            subtitle={`Alert when stock < ${LOW_STOCK_ALERT_THRESHOLD} units`}
            value={lowStockAlert}
            onToggle={setLowStockAlert}
          />
          <View style={s.sep} />
          <SettingToggle
            icon={<BellIcon color="#22c55e" />}
            label="Sound & Vibration"
            subtitle="Play sound on new sale"
            value={soundEnabled}
            onToggle={setSoundEnabled}
          />
        </View>

        {/* Billing */}
        <SectionHeader title="BILLING & PRINTING" />
        <View style={s.card}>
          <SettingToggle
            icon={<PrinterIcon />}
            label="Auto-Print Bill"
            subtitle="Print immediately after sale"
            value={autoPrint}
            onToggle={setAutoPrint}
          />
          <View style={s.sep} />
          <SettingLink
            icon={<PrinterIcon color="#a78bfa" />}
            label="Bill Footer Text"
            subtitle="Customize thank-you message"
            onPress={() => Alert.alert('Bill Footer', 'Edit footer text — coming soon!')}
          />
        </View>

        {/* Security */}
        <SectionHeader title="SECURITY" />
        <View style={s.card}>
          <SettingLink
            icon={<LockIcon />}
            label="Change Password"
            subtitle="Update your login password"
            onPress={() => setPasswordModalVisible(true)}
          />
          <View style={s.sep} />
          <SettingLink
            icon={<LockIcon color="#f59e0b" />}
            label="Staff PIN Settings"
            subtitle="Manage staff access PINs"
            onPress={() => Alert.alert('Staff PIN', 'Feature coming soon!')}
          />
        </View>

        {/* About */}
        <SectionHeader title="ABOUT" />
        <View style={s.card}>
          <SettingLink
            icon={<InfoIcon />}
            label="App Version"
            subtitle={`v${APP_VERSION} · ${APP_NAME}`}
            onPress={() => {}}
          />
        </View>

        {/* Logout */}
        <SectionHeader title="" />
        <View style={s.card}>
          <SettingLink
            icon={<UserIcon color="#ef4444" />}
            label="Logout"
            subtitle="Sign out of your account"
            onPress={handleLogout}
            danger
          />
        </View>

        <Text style={s.footer}>{APP_NAME} · v{APP_VERSION}</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F5F6FA' },

  // Header
  header: {
    backgroundColor: '#fff',
    paddingHorizontal: 20, paddingVertical: 14,
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderBottomWidth: 1, borderBottomColor: '#eee', elevation: 2,
  },
  backBtn: {
    width: 36, height: 36, backgroundColor: '#EEF0FF',
    borderRadius: 10, alignItems: 'center', justifyContent: 'center',
  },
  headerCenter: { flex: 1 },
  headerTitle: { fontSize: 18, fontWeight: '800', color: BLUE },
  headerSub: { fontSize: 11, color: '#aaa', marginTop: 1 },

  scroll: { padding: 16, paddingBottom: 40 },

  // Profile card
  profileCard: {
    backgroundColor: BLUE, borderRadius: 16, padding: 18,
    flexDirection: 'row', alignItems: 'center', gap: 14,
    marginBottom: 20, elevation: 4,
  },
  profileAvatar: {
    width: 50, height: 50, borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: 'rgba(255,255,255,0.4)',
  },
  profileAvatarText: { color: '#fff', fontSize: 18, fontWeight: '800' },
  profileText: { flex: 1 },
  profileName: { color: '#fff', fontSize: 15, fontWeight: '800' },
  profileRole: { color: 'rgba(255,255,255,0.65)', fontSize: 12, marginTop: 2 },
  profileBadge: {
    backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  profileBadgeText: { color: '#fff', fontSize: 10, fontWeight: '800', letterSpacing: 1 },

  // Section header
  sectionHeader: {
    fontSize: 10, fontWeight: '800', color: '#94A3B8',
    letterSpacing: 1.2, marginBottom: 8, marginTop: 4, paddingHorizontal: 4,
  },

  // Card
  card: {
    backgroundColor: '#fff', borderRadius: 16, marginBottom: 12,
    overflow: 'hidden', elevation: 2,
    shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8,
  },
  sep: { height: 1, backgroundColor: '#F1F5F9', marginLeft: 66 },

  // Rows
  row: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14, gap: 12,
  },
  rowIcon: {
    width: 38, height: 38, borderRadius: 10,
    backgroundColor: '#EEF0FF',
    alignItems: 'center', justifyContent: 'center',
  },
  rowIconDanger: { backgroundColor: '#FEE2E2' },
  rowText: { flex: 1 },
  rowLabel: { fontSize: 14, fontWeight: '700', color: '#1E293B' },
  rowLabelDanger: { color: '#ef4444' },
  rowSub: { fontSize: 11, color: '#94A3B8', marginTop: 2 },

  footer: { textAlign: 'center', color: '#94A3B8', fontSize: 11, marginTop: 8 },

  // Modal / Sheet
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  handle: { width: 40, height: 4, backgroundColor: '#E2E8F0', borderRadius: 2, alignSelf: 'center', marginBottom: 20 },
  sheetTitle: { fontSize: 20, fontWeight: '900', color: '#1E293B', marginBottom: 4 },
  sheetSub: { fontSize: 13, color: '#94A3B8', marginBottom: 16 },
  lbl: { fontSize: 10, color: '#94A3B8', fontWeight: '700', letterSpacing: 1.2, marginBottom: 6, marginTop: 14 },
  inp: { backgroundColor: '#F8F9FF', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: '#1E293B', borderWidth: 1, borderColor: '#E2E8F0' },
  btnRow: { flexDirection: 'row', gap: 12, marginTop: 24 },
  cancelBtn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center', borderWidth: 1, borderColor: '#E2E8F0' },
  cancelTxt: { color: '#64748B', fontWeight: '700', fontSize: 14 },
  saveBtn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center', backgroundColor: BLUE },
  saveTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
